#pragma once
#include <string>

enum class DegreeProgram { SECURITY, NETWORK, SOFTWARE }; //define the enumerator class
static const std::string degreeTypeStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" }; //used for print outputs